from CardHolder import CardHolder

def print_menu():
    ###print OPtions of the user
    print('please choose from one of the following options-')
    print('1. Deposit')
    print('2. Withdraw')
    print('3. Show Balance')
    print('4.Exit')
def deposit(CardHolder):
    try:
        deposit=float(input('How much Rs would you like to deposit: '))
        CardHolder.set_balance(CardHolder.get_balance + deposit)
        print('Thank You for your Rs.Your new balance is: ',str(CardHolder.get_balance()))
    except:
        print('Invalid Input')
def withdraw(CardHolder):
    try:
        Withdraw=float(input('How much Rs would you withdraw: '))
        ##check if user has enough  balance
        if(CardHolder.get_balance()< Withdraw):
            print('Insufficient Balance :( ')
        else:
            CardHolder.set_balance(CardHolder.get_balance() - Withdraw)
            print('Thank You :)')
    except:
        print("Thank You :) ")
def check_balance(CardHolder):
    print('Your current balance is:',CardHolder.get_balance())
if __name__=="__main__":
    current_user=CardHolder('','','','','')
    #create repo for catdholders
    list_of_CardHolders=[]
    list_of_CardHolders.append(CardHolder('56451545656445878',1254,'John','Grifth',15024))
    list_of_CardHolders.append(CardHolder('87965824525698655',9875,'Lisa','Sliten',40024))
    list_of_CardHolders.append(CardHolder('12512556556686966',1365,'Daniell','hort',14580))
    list_of_CardHolders.append(CardHolder('57895723223000023',5873,'Gabriel','ling',56002))
    list_of_CardHolders.append(CardHolder('98759696589821234',2287,'Gojo','Satoru',5449865))
    #prompt user for debitcardnum
    debitcardnum=''
    while True:
        try:
            debitcardnum=input('Please insert your debit card:')
            ## check again repo
            debitmatch=[holder for holder in list_of_CardHolders if holder.cardnum==debitcardnum]
            if(len(debitmatch)>0):
                current_user=debitmatch[0]
                break
            else:
                print('Card number not recognised. Please try agien.')
        except:
            print('card number is not recognised.Please try again.')
    ###promt for PIN
    while True:
        try:
            userPin=int(input('Please enter your Pin:').strip())
            if(current_user.get_pin()==userPin):
                break
            else:
                print('Invalid PIN.Please try again.')
        except:
             print('Invalid PIN.Please try again.')
    ##print options
    print('Welcome',current_user.get_firstname(),':)')
    option=0
    while(True):
        print_menu()

        try:
            option=int(input())
        except:
            print('Invalid input.Please Try again:')
        if(option==1):
            deposit(current_user)
        elif(option==2):
            withdraw(current_user)
        elif(option==3):
            check_balance(current_user)
        elif(option==4):
            break
        else:
            option=0
            
    print('Thank You. Have a nice day! :)')